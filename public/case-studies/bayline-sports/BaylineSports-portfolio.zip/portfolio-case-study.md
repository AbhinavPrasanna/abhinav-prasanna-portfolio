# Bayline Sports
## A Bay Area sports dashboard, built from concept through production recovery

**Live application:** [baylinescore.com](https://baylinescore.com/)  
**Source repository:** [AbhinavPrasanna/BayAreaSports](https://github.com/AbhinavPrasanna/BayAreaSports)  
**Development period:** October 20–23, 2026; case study prepared October 24, 2026.  
**Role:** Product direction and full-stack delivery, developed in collaboration with OpenAI Codex.  
**Stack:** Next.js, React, TypeScript, PostgreSQL, Node.js, Docker Compose, AWS, BALLDONTLIE and YouTube Data API.

## Portfolio overview

I designed and shipped Bayline Sports, a mobile-friendly dashboard that brings Bay Area game schedules, scores, records, player statistics, official highlights and injury reports into one experience. The production MVP covers the Golden State Warriors, San Francisco 49ers and Golden State Valkyries. Fans can follow teams, find the next game, browse a combined schedule and review game details while controlling how much of a result they see.

The project began with a five-team concept and a $100-per-month AWS budget. I validated provider coverage before expanding the interface, started with free-tier game data and added NBA/NFL player statistics and injury reports after purchasing access. I worked with Codex across architecture, implementation, testing, debugging and deployment, while directing product scope and handling account access, subscriptions, domain registration and owner-session releases.

The result is a publicly deployed application with independently scheduled ingestion, cached data access, protected API credentials, automated backups, uptime monitoring and a documented recovery procedure. The work demonstrates full-stack product delivery and the operational decisions needed to keep a small application maintainable.

![Bayline home page during development](images/hero-desktop.png)

## The problem and product direction

Following local teams across different sports requires moving between league websites, scoreboards, broadcast schedules, highlight channels and injury reports. Different seasons, game states and data subscriptions make a combined experience more complicated than a list of scores.

The initial scope included the Warriors, 49ers, Valkyries, San Jose Sharks and San Jose Earthquakes. Discussion covered functional requirements, score/event freshness, database structure, reconnecting clients, sports-data licensing and AWS operating cost. Provider validation then informed the release scope: NBA, NFL and WNBA schedules/scores formed the MVP; Sharks/NHL and Earthquakes/MLS remained a future expansion because their game-data access required additional paid coverage.

The implementation focused on practical fan tasks: find the next game, check followed teams comfortably on a phone, see available viewing options, review a completed game and avoid spoilers when watching later.

## The fan experience

### Schedule and scores

The scoreboard includes Today, a combined weekly/day schedule, recent Results and Live now views. Next-game cards surface each followed team's upcoming matchup. Times are displayed in Pacific time with date and daylight-saving handling. Scheduled, live, final, delayed and postponed states stay distinct, and an upcoming game's placeholder zero is not displayed as a played score.

Fans can use the application without creating an account, and save their team selections and spoiler preference locally on the device. Refreshes preserve the current view and scroll position. The browser reads cached snapshots every 15 seconds while visible and online, and immediately refetches on reconnect, focus or return to the app.

### Game details, records and statistics

Game dialogs show matchup information, freshness, viewing/highlight options and supported statistical detail. NBA/NFL advanced details include regulation-quarter scores, overtime and both teams' player statistics. Basketball tables cover minutes, scoring, rebounds, assists, defense and shooting; NFL tables separate passing, rushing, receiving, defense and kicking.

The app tracks regular-season and playoff records separately, displays records entering a game, and supports postgame totals. The Valkyries–Dream Finals feature adds reviewed series metadata, game numbers, conditional future games and a separate series record. It is a scoped feature for the configured series, rather than a generalized bracket engine.

WNBA advanced details are omitted where the configured feed does not provide the required quarter/player data. Missing data remains unknown instead of being filled with invented values.

### Streaming links and official highlights

Upcoming games can display reviewed U.S. broadcast/streaming links with location and subscription context. Missing listings link to official viewing guides rather than claiming a confirmed broadcaster.

Completed games support official YouTube highlights with a click-to-load miniplayer. Discovery uses the official NBA channel for Warriors games, NFL channel for 49ers games and WNBA channel for Valkyries games. The independent worker checks league upload playlists, validates video metadata, matches teams and game timing, and stores approved matches. Human-reviewed entries take precedence, and unavailable or ambiguous matches retain an official-source fallback.

The worker avoids YouTube's search endpoint and uses bounded discovery, persisted quotas, retries and metadata expiry. A video can be viewable on YouTube while restricted from embedding, so the interface supports an external-link fallback. Highlight timing depends on league publication and subsequent discovery.

### Injury Report and team rosters

An Injury Report tab sits beside Scoreboard. Warriors and 49ers icon buttons show one team's current roster and reported injuries, with a selected-state outline and accessible labels. Fans can search names or positions and filter reported injuries, reported availability or players with no listed injury. The same report content is available inside game details.

Reports show provider status, injury commentary, report dates and return estimates when supplied. A player absent from the injury feed is labeled **No reported injury**, not automatically declared healthy. Reports opened from completed games clearly identify themselves as current team reports, not historical game-day status. WNBA injury coverage remains unavailable with the configured plan.

### Spoiler protection throughout the product

Spoiler protection hides scores, winner styling, records and statistical outcomes. Highlight titles, links and players stay hidden until explicitly revealed. Injury commentary can mention recent results, so reports also have an independent reveal action. Viewing highlights or a report does not reveal the score. Switching injury-report teams resets the reveal state for the newly selected team.

![Warriors and 49ers icon selector, verified on the live application](images/injury-team-icons-live-phone.png)

## Architecture and data flow

The application uses a small, modular architecture sized for the MVP:

```mermaid
flowchart LR
  Fan[Fan browser] -->|HTTPS| Edge[Caddy reverse proxy]
  Edge --> Web[Next.js interface and read APIs]
  Web --> DB[(Private PostgreSQL)]
  Worker[Independent Node.js worker] -->|Scheduled ingestion| Sports[BALLDONTLIE]
  Worker -->|Official video discovery| YouTube[YouTube Data API]
  Worker -->|Validated snapshots| DB
  DB --> Backup[Private off-server backup storage]
  Monitor[Scheduled AWS uptime monitor] -->|HTTPS readiness check| Edge
```

The browser calls the application's own APIs. External credentials stay on the worker, and browser refreshes do not consume sports-provider quota. Web restarts do not restart the ingestion schedule.

The browser's 15-second interval is a cache-refresh interval. Sports ingestion targets checks about once a minute, subject to provider limits, pagination, queue contention and backoff. Injury reports target roughly ten-minute checks. This release uses snapshot polling; a dedicated play-by-play event stream and WebSocket/SSE delivery were discussed as future possibilities and were not implemented.

The release uses Next.js 16.4.2, React 19.3.1, Node.js 24 and PostgreSQL 17, with TypeScript, Zod runtime validation, direct PostgreSQL access and ordered SQL migrations. The interface uses custom CSS and reusable React components.

### Server and database design

TypeScript shared types describe normalized games independently of a league's raw response shape. Provider adapters handle league endpoints and validation. Server modules separate configuration, database access, ingestion and API behavior. React components provide reusable game cards, records, details, media and player reports.

PostgreSQL stores games under the composite identity `(league, provider_id)`, preventing cross-league ID collisions. Transactional upserts handle repeated observations and provider corrections without duplicating games. Timestamps distinguish when data was observed from when its values changed. Core entities and operational state use relational tables; line scores, player-stat snapshots, media and roster/report payloads use validated JSON/JSONB where appropriate.

Eight SQL migrations cover foundation data, game ingestion, operational checks, reviewed media, automatic highlights, season records, advanced statistics and player status. Persistent sync state records cursors, next-check times, failures and successful snapshots.

A PostgreSQL advisory lock ensures a single scheduler owns ingestion. Provider requests reserve a persistent shared slot at least 14 seconds apart, retaining a conservative limit as optional features were added. Pagination bounds, timeouts, scope checks and rate-limit backoff protect completeness. Failed or partial fetches retain the previous successful data instead of replacing it with an empty or misleading snapshot.

### Read APIs

- `GET /api/games`: bounded schedule/results/live queries with team records and freshness metadata.
- `GET /api/games/{league}/{id}`: a game snapshot with supported statistical, media and report detail.
- `GET /api/player-status`: cached current reports for the configured followed teams.
- `GET /api/teams`: the enabled team catalog.
- `GET /api/health`: application/database reachability.
- `GET /api/ready`: worker, score-feed, backup and restore readiness.

Game lists omit large roster/player-detail payloads. Reconnecting clients refetch a current snapshot through the same read APIs.

## How the project developed

### October 20: requirements and provider validation

The discussion moved from a regional sports-app concept through requirements, architecture, schema/API design, data fees and an affordable MVP. The key decision was to validate BALLDONTLIE access before building unsupported features. API keys were configured outside chat/source with Windows-account encryption and restricted files. Paid NHL/MLS functionality was deferred.

### October 21: foundation, fan experience and public launch

The repository established Next.js, TypeScript, PostgreSQL, migrations, Docker Compose and a worker that runs independently of the web process. Early troubleshooting addressed disabled PowerShell scripts, a stopped Docker engine, a host-port bind failure and migration startup problems. Safe startup logs and more specific preflight checks made failures easier to diagnose.

Scheduled ingestion and the phone-oriented scoreboard followed. Today, schedules, game details, saved preferences, spoilers, visible refresh, reconnect behavior and scroll preservation were added and checked in the browser. GitHub became the source repository.

Production work added prebuilt containers, private database networking, HTTPS, monitoring, backups, restart policies and recovery documentation. The first public launch used the server address; the project then moved to the registered domain **baylinescore.com**, including DNS, trusted HTTPS and a `www` redirect. The hero artwork and navigation were refined, and reviewed viewing links/highlights were added.

### October 22: richer game data and automated content

Official highlight discovery was implemented, initially kept disabled until a restricted YouTube key was ready, then validated and activated. Season records and historical per-game records followed. Quarter scores were introduced, with unsupported WNBA detail removed rather than shown as a permanent empty panel.

After NBA/NFL premium access was purchased, player-stat ingestion was activated. Investigation of missing older 49ers statistics found that the jobs used a 31-day cutoff while the schedule covered 45 Pacific calendar days. Aligning the windows and testing the inclusive boundary restored the missing games. Finals series records and current roster/injury reports extended the experience.

### October 23: dedicated injury navigation and team selection

Injury Report became a top-level page, followed by dedicated Warriors and 49ers icon buttons. Live verification covered one-team display, player search, filtering, refresh, spoiler behavior and phone widths. These releases replaced only the web container and preserved the worker/database processes.

This sequence was iterative: each feature was scoped against available data, implemented, validated locally or in the Linux build, deployed with bounded checks, then verified on the live application.

## Deployment, security and recovery

Production runs on an AWS Lightsail instance using Docker Compose. Caddy exposes HTTPS; PostgreSQL stays on a private internal container network. Next.js and the worker use separately built images pinned by digest. AWS CodeBuild validates and builds source archives, ECR stores images, and owner-invoked release helpers deploy them. GitHub stores source; automatic deployment on every Git push is not part of the documented pipeline.

Production credentials use restricted host-mounted files. Only the worker receives sports/YouTube keys. Configuration is validated on startup, and diagnostic output avoids printing credentials. Windows setup uses encrypted local key storage; AWS sign-in and some publishing steps run from the owner's normal PowerShell session because of sandbox access restrictions.

Containers have restart policies, resource limits, restricted privileges and rotating logs. Systemd starts the stack on boot, schedules backups and restore checks, and runs a watchdog. Verified backups are stored off-server every six hours with 35-day retention. Release archives preserve matching source and deployment configuration.

An independent scheduled AWS monitor requests the public readiness endpoint and checks certificate validity. CloudWatch/SNS notification actions were tested through an outage and recovery. AWS budget alerts provide spending visibility; they are not a spending cutoff.

Recovery validation included forced process failures, a host reboot and restoring a backup into a separate database. The migration-008 restore verified the recovery canary, eight migrations, three teams, 45 games and the populated player-status caches, along with existing stats/records/media. A full replacement-host recovery was documented but not timed. The RPO target is six hours plus backup execution time; the RTO target is one to two hours after operator access is available.

## Validation and demonstrated outcomes

- Public HTTPS application with a registered custom domain and GitHub source repository.
- Three teams supported for schedules/scores; paid NBA/NFL player statistics and current injury reports.
- 71 application tests in the latest recorded suite, with PostgreSQL behavior exercised through PGlite; four recovery guard tests were also recorded.
- Eight SQL migrations and 41 repository commits at the case-study snapshot.
- Phone verification at 320- and 390-pixel widths, including icon selection, spoiler protection and no horizontal page overflow.
- Verified off-server backups and isolated database restoration, plus process-restart and host-reboot recovery checks.
- A modular provider boundary and cached read APIs that support future expansion without exposing credentials to the browser.

These are development and release results. The project does not yet claim measured production-scale throughput, audience growth, a formal availability percentage or second-level upstream score latency.

## Cost and scope boundaries

The AWS design targeted a **$100/month project budget**, using a **$24/month Lightsail instance** as the main fixed component. Deployment documentation estimated **$30–40/month in AWS infrastructure** at modest MVP traffic, including small build/storage/monitoring costs and contingency. That is a planning estimate, not an audited invoice.

Premium sports-data subscriptions, annual domain registration, taxes and exceptional usage require separate allowance. The exact NBA/NFL subscription bill was not verified for this case study. No managed RDS database, load balancer or NAT gateway was required for the initial design. The single-server deployment keeps cost and operational complexity low while leaving high availability as future work.

## AI-assisted development and recorded usage

I used Codex as an implementation, debugging, testing and deployment collaborator. AI assisted the development workflow; the deployed fan experience does not invoke an OpenAI model. The retained thread records the model identifier **`gpt-6.1-sol`** with high reasoning effort. I directed the feature priorities and accepted tradeoffs, supplied service access through secure setup, purchased data access, registered the domain and ran owner-session commands when required.

Before this case-study request, the detailed local log recorded **235,532,019 cumulative tokens across 1,194 distinct model-response usage records**. This included 234,698,618 input tokens and 833,401 output tokens. Of the input, 231,133,696 tokens were cached: **98.48% of input**. Uncached input totaled 3,564,922 tokens. The output counter included 343,096 reasoning-output tokens; those are already part of output and are not added again.

These cumulative counters include repeated conversation, tool and instruction context. They do not represent 235 million unique words or a single prompt. The session recorded seven context compactions and a 475,000-token context-window field. The tally excludes this summary request and cannot establish the cost of a ChatGPT/Codex subscription or external tools. It covers the retained Codex thread; earlier brainstorming outside its usage records and unrelated threads are outside the measurement.

See [Usage methodology](usage-methodology.md) for the reconciliation and boundaries. For a public portfolio, the product and engineering results should lead; token usage is optional process context.

## What I learned and what comes next

The most useful lesson was to make product promises match data and operational evidence. A polished scoreboard needs clear unknown/delayed states, careful historical boundaries, quota-aware jobs and recovery that works outside the application process. Spoiler protection also needs to cover indirect signals such as records, injury commentary and video titles.

Future work includes validating and enabling Sharks/Earthquakes coverage, broader verified broadcast listings, supported WNBA advanced data, generalized postseason metadata, larger-load measurements, a timed replacement-host recovery exercise and evaluating event streaming if the data provider and product requirements justify it. These are planned extensions, not shipped capabilities.

---

Prepared from this project's conversation, repository history, implementation, deployment/runbook records, release evidence and scoped local model-usage metadata. Screenshots are development/live-verification captures from October 21–23, 2026. Internal account identifiers, secrets, personal contact details and raw session transcripts are intentionally excluded.
