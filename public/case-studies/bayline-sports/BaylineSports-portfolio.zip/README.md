# Bayline portfolio package

Start with [Portfolio copy](portfolio-copy.md) for a project card, first-person overview and résumé bullets.

Read [Complete case study](portfolio-case-study.md) for the product, architecture, development timeline, deployment, debugging, recovery, cost boundaries and roadmap.

See [Usage methodology](usage-methodology.md) and [sanitized usage evidence](usage-evidence.json) for the recorded model and token totals.

The `images/` directory contains four existing project screenshots. They show development/live-verification states from October 21–23, 2026. They are historical captures, not a claim of a new live verification on October 24.

This is a documentation package. It does not modify or deploy the sports application, publish anything to GitHub, or contain raw session logs/API credentials. Review the wording and choose the sections you want to publish in your portfolio.
