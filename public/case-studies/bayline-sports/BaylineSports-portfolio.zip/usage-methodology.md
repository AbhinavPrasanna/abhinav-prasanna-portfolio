# Model and token-usage methodology

This appendix describes the retained Codex thread for Bayline. The snapshot stops before the portfolio-summary request. Its last included usage record is October 23, 2026 at 14:17:33 Pacific (21:17:33 UTC). The summary request began October 24 at 22:31:06 Pacific (October 25 UTC); its own generation/inspection tokens are excluded.

## Result

- Recorded model identifier: **`gpt-6.1-sol`**.
- Recorded reasoning setting: **high**, in all 82 pre-summary turn-context records.
- Distinct model-response usage records: **1,194**.
- Total input tokens: **234,698,618**.
- Cached input tokens, already included in input: **231,133,696**.
- Uncached input tokens: **3,564,922**.
- Total output tokens: **833,401**.
- Reasoning-output tokens, already included in output: **343,096**.
- Cumulative input plus output: **235,532,019**.
- Cached share of input: **98.481064%**.
- Recorded context-window field: **475,000 tokens**.
- Recorded context compactions: **7**.

These are scoped local-log measurements. The model identifier is the configured identifier recorded in this thread, not an independently verified backend model audit. Turn-context records are configuration records; the 1,194 response records describe a different unit and should not be described as 1,194 human prompts.

## Calculation and cross-check

1. Locate the current thread's exact local rollout file; do not inspect unrelated session content.
2. Read only metadata and usage fields, retaining records before the summary request's start time.
3. Select `token_usage_record` entries and deduplicate by response identifier. All 1,194 recorded entries had distinct response identifiers.
4. Sum each entry's `payload.usage` numeric counters.
5. Verify that the sum equals the last `payload.thread_token_usage` counters. All fields matched, and the cumulative thread total never decreased in the inspected records.
6. Verify `input_tokens + output_tokens = total_tokens`.
7. Derive uncached input as input minus cached input; derive cache share as cached input divided by total input.

The sanitized calculation is saved in [usage-evidence.json](usage-evidence.json). Raw transcripts, response IDs, thread IDs, authentication data and personal contact information are not included in the deliverables.

## Why another counter differs

The older `event_msg` → `token_count` → `info.total_token_usage` view ended at **232,965,389**, whereas detailed response usage and the cumulative thread counter both ended at **235,532,019**. The difference is **2,566,630 tokens**. This report uses the independently summed detailed response records because they reconcile exactly with the thread counter. It does not guess the cause of the older counter's discrepancy, sum repeated cumulative events, or silently add both streams together.

## Interpretation

Cumulative usage can greatly exceed the capacity of one context window because each model response processes its current context again. Cached prefixes are repeatedly counted as input, and compaction allows work to continue across a long project. A 235.53-million cumulative token total therefore does not imply a single 235.53-million-token prompt or that the project produced that much unique text/code.

Cached input is already included in input; reasoning output is already included in output. Adding either a second time would inflate the total. Uncached input also should not be labeled unique text: repeated material can miss cache, and instructions/tool output contribute to context.

The tally covers this retained thread, including logged project work and troubleshooting. It excludes this case-study request, unrelated threads and earlier brainstorming not represented by these usage records. It does not independently measure image-generation usage, web-tool charges, sports/YouTube fees, AWS costs or the price actually paid for a ChatGPT/Codex plan. Do not convert this counter into a dollar bill using an assumed public API rate.

Official OpenAI documentation describes session status/model/usage inspection and token counters: [Developer commands](https://learn.chatgpt.com/docs/developer-commands). That documentation explains the inspection surface; the numeric values above come from this project's local records.

## Portfolio wording

“Developed in collaboration with OpenAI Codex using the recorded model `gpt-6.1-sol`. The retained project thread logged 235.53 million cumulative tokens before the case-study request, with 98.48% of input cached. These counters include repeated conversation and tool context.”

For a hiring portfolio, the application, engineering decisions and verified results should lead. Include the usage paragraph only when describing the AI-assisted development process. The production fan experience itself does not invoke an OpenAI model; AI was used as a development tool.
