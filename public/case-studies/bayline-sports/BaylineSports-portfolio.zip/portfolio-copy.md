# Portfolio and résumé copy

## Project card

**Bayline Sports — Bay Area sports dashboard**

A mobile-friendly sports dashboard for the Warriors, 49ers and Golden State Valkyries, combining schedules, scores, records, player statistics, official highlights and injury reports. Built with Next.js, TypeScript and PostgreSQL, with independent data ingestion and a Docker-based AWS deployment. Includes device-saved preferences, spoiler protection, automated backups and verified recovery checks.

[Live application](https://baylinescore.com/) · [Source](https://github.com/AbhinavPrasanna/BayAreaSports)

## First-person overview

I designed and shipped Bayline Sports to make following Bay Area teams easier across the NBA, NFL and WNBA. Fans can find the next game, browse a combined schedule, check scores and statistics, watch official highlights and search current injury reports. Team preferences and spoiler protection keep the experience useful for fans watching games later.

I started by validating sports-provider coverage and narrowing a five-team concept to a realistic MVP. I separated a Node.js ingestion worker from the Next.js web application, normalized league data into PostgreSQL and served cached snapshots through read-only APIs. The browser refreshes every 15 seconds while visible and refetches on reconnect; provider requests remain centrally rate-controlled and keep the last complete snapshot on failure.

I deployed the application to AWS Lightsail with prebuilt, digest-pinned containers, a private database network and automatic HTTPS on baylinescore.com. The deployment includes uptime/budget alerts, rotating logs, off-server backups and a documented recovery procedure. Validation grew to 71 application tests, phone-width browser checks, forced-process recovery, a host reboot and isolated backup restoration. I led product decisions and delivery in collaboration with Codex, using AI assistance for implementation, debugging, testing and release work.

## Résumé bullets

- Designed and shipped a Next.js/TypeScript sports dashboard covering three Bay Area teams, with game schedules, scores, records, official highlights, NBA/NFL player statistics and searchable injury reports.
- Built an independent Node.js ingestion worker with PostgreSQL advisory locking, persistent request throttling, transactional upserts and retry/backoff behavior; served cached snapshots with 15-second visible browser refresh and reconnect recovery.
- Deployed Docker services to AWS Lightsail behind Caddy HTTPS, keeping PostgreSQL private and provider keys worker-only; configured off-server backups, uptime/budget alerts and documented disaster recovery.
- Validated the application with 71 tests, real PostgreSQL SQL behavior through PGlite, mobile browser checks and isolated backup restoration; fixed a historical-statistics backfill bug by aligning schedule and ingestion date boundaries.

## Technology list

Next.js · React · TypeScript · Node.js · PostgreSQL · SQL migrations · Zod · Docker Compose · Caddy · AWS Lightsail · CodeBuild · ECR · Route 53 · CloudFormation · Lambda · CloudWatch · SNS · EventBridge · BALLDONTLIE · YouTube Data API · Git/GitHub · PGlite · PowerShell · Python recovery tooling.

## Optional AI workflow disclosure

Developed in collaboration with OpenAI Codex; retained session metadata records `gpt-6.1-sol`. I led scope, data-access decisions, account setup and release approval, and used the assistant for implementation, testing, debugging and operational documentation. Detailed local records show 235.53 million cumulative tokens before the case-study request, with 98.48% of input cached. Token counters describe repeated context processing and are not a measure of unique code or a verified dollar cost.

## Claims to keep precise

- Say browser snapshots refresh every 15 seconds; actual upstream scores depend on provider checks and availability.
- Say the MVP covers three teams; Sharks and Earthquakes remain future work.
- Say AWS was designed for a $100/month budget, with a documented $30–40 planning estimate; do not present that estimate as an audited bill or include unverified subscription prices.
- Say recovery was exercised through isolated database restoration, process failures and host reboot; a timed replacement-host exercise remains future work.
- Say 71 application tests passed in recorded validation; do not claim measured scale, user growth, formal uptime or complete league-wide coverage.
